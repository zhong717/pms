using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.DBUtility;//������������
namespace TSM.DAL
{
	/// <summary>
	/// ���ݷ�����CK_SendGoods��
	/// </summary>
	public class CK_SendGoods
	{
		public CK_SendGoods()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("CK_SendGoodsID", "CK_SendGoods"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int CK_SendGoodsID)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from CK_SendGoods");
			strSql.Append(" where CK_SendGoodsID=@CK_SendGoodsID ");
			SqlParameter[] parameters = {
					new SqlParameter("@CK_SendGoodsID", SqlDbType.Int,4)};
			parameters[0].Value = CK_SendGoodsID;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(TSM.Model.CK_SendGoods model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into CK_SendGoods(");
			strSql.Append("CK_PeopleID,CK_ProductID,CK_SendGoodsNo,CK_SendGoodsAmount,CK_SendGoodsDate)");
			strSql.Append(" values (");
			strSql.Append("@CK_PeopleID,@CK_ProductID,@CK_SendGoodsNo,@CK_SendGoodsAmount,@CK_SendGoodsDate)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@CK_PeopleID", SqlDbType.Int,4),
					new SqlParameter("@CK_ProductID", SqlDbType.Int,4),
					new SqlParameter("@CK_SendGoodsNo", SqlDbType.VarChar,32),
					new SqlParameter("@CK_SendGoodsAmount", SqlDbType.Int,4),
					new SqlParameter("@CK_SendGoodsDate", SqlDbType.DateTime)};
			parameters[0].Value = model.CK_PeopleID;
			parameters[1].Value = model.CK_ProductID;
			parameters[2].Value = model.CK_SendGoodsNo;
			parameters[3].Value = model.CK_SendGoodsAmount;
			parameters[4].Value = model.CK_SendGoodsDate;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(TSM.Model.CK_SendGoods model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update CK_SendGoods set ");
			strSql.Append("CK_PeopleID=@CK_PeopleID,");
			strSql.Append("CK_ProductID=@CK_ProductID,");
			strSql.Append("CK_SendGoodsNo=@CK_SendGoodsNo,");
			strSql.Append("CK_SendGoodsAmount=@CK_SendGoodsAmount,");
			strSql.Append("CK_SendGoodsDate=@CK_SendGoodsDate");
			strSql.Append(" where CK_SendGoodsID=@CK_SendGoodsID ");
			SqlParameter[] parameters = {
					new SqlParameter("@CK_SendGoodsID", SqlDbType.Int,4),
					new SqlParameter("@CK_PeopleID", SqlDbType.Int,4),
					new SqlParameter("@CK_ProductID", SqlDbType.Int,4),
					new SqlParameter("@CK_SendGoodsNo", SqlDbType.VarChar,32),
					new SqlParameter("@CK_SendGoodsAmount", SqlDbType.Int,4),
					new SqlParameter("@CK_SendGoodsDate", SqlDbType.DateTime)};
			parameters[0].Value = model.CK_SendGoodsID;
			parameters[1].Value = model.CK_PeopleID;
			parameters[2].Value = model.CK_ProductID;
			parameters[3].Value = model.CK_SendGoodsNo;
			parameters[4].Value = model.CK_SendGoodsAmount;
			parameters[5].Value = model.CK_SendGoodsDate;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int CK_SendGoodsID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from CK_SendGoods ");
			strSql.Append(" where CK_SendGoodsID=@CK_SendGoodsID ");
			SqlParameter[] parameters = {
					new SqlParameter("@CK_SendGoodsID", SqlDbType.Int,4)};
			parameters[0].Value = CK_SendGoodsID;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public TSM.Model.CK_SendGoods GetModel(int CK_SendGoodsID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 CK_SendGoodsID,CK_PeopleID,CK_ProductID,CK_SendGoodsNo,CK_SendGoodsAmount,CK_SendGoodsDate from CK_SendGoods ");
			strSql.Append(" where CK_SendGoodsID=@CK_SendGoodsID ");
			SqlParameter[] parameters = {
					new SqlParameter("@CK_SendGoodsID", SqlDbType.Int,4)};
			parameters[0].Value = CK_SendGoodsID;

			TSM.Model.CK_SendGoods model=new TSM.Model.CK_SendGoods();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["CK_SendGoodsID"].ToString()!="")
				{
					model.CK_SendGoodsID=int.Parse(ds.Tables[0].Rows[0]["CK_SendGoodsID"].ToString());
				}
				if(ds.Tables[0].Rows[0]["CK_PeopleID"].ToString()!="")
				{
					model.CK_PeopleID=int.Parse(ds.Tables[0].Rows[0]["CK_PeopleID"].ToString());
				}
				if(ds.Tables[0].Rows[0]["CK_ProductID"].ToString()!="")
				{
					model.CK_ProductID=int.Parse(ds.Tables[0].Rows[0]["CK_ProductID"].ToString());
				}
				model.CK_SendGoodsNo=ds.Tables[0].Rows[0]["CK_SendGoodsNo"].ToString();
				if(ds.Tables[0].Rows[0]["CK_SendGoodsAmount"].ToString()!="")
				{
					model.CK_SendGoodsAmount=int.Parse(ds.Tables[0].Rows[0]["CK_SendGoodsAmount"].ToString());
				}
				if(ds.Tables[0].Rows[0]["CK_SendGoodsDate"].ToString()!="")
				{
					model.CK_SendGoodsDate=DateTime.Parse(ds.Tables[0].Rows[0]["CK_SendGoodsDate"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select * ");
            strSql.Append(" FROM v_listSendGoodsInfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

        public DataSet GetTakeSendStatList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" FROM v_listTakeSendGoodsInfo ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }
        public DataSet GetPayDetailList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" FROM v_listPayDetailInfo ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" CK_SendGoodsID,CK_PeopleID,CK_ProductID,CK_SendGoodsNo,CK_SendGoodsAmount,CK_SendGoodsDate ");
			strSql.Append(" FROM CK_SendGoods ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
            parameters[0].Value = "v_listSendGoodsInfo";
            parameters[1].Value = "CK_SendGoodsID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}

        public DataSet GetTakeSendGoodsStatList(int PageSize, int PageIndex, string strWhere)
        {
            SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
            parameters[0].Value = "v_listTakeSendGoodsInfo";
            parameters[1].Value = "ck_PeopleName";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;
            return DbHelperSQL.RunProcedure("UP_GetRecordByPage", parameters, "ds");
        }

        public DataSet GetPayDetailList(int PageSize, int PageIndex, string strWhere)
        {
            SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
            parameters[0].Value = "v_listPayDetailInfo";
            parameters[1].Value = "ck_PeopleName";
            parameters[2].Value = PageSize;
            parameters[3].Value = PageIndex;
            parameters[4].Value = 0;
            parameters[5].Value = 0;
            parameters[6].Value = strWhere;
            return DbHelperSQL.RunProcedure("UP_GetRecordByPage", parameters, "ds");
        }
		#endregion  ��Ա����
	}
}

